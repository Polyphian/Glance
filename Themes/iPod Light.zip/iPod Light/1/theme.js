//City
ctx.font = 'bold 69px -apple-system';
ctx.textAlign = "center";
ctx.textBaseline = "top";
ctx.fillStyle = "#BBBCC0";
ctx.shadowOffsetY = 2;
ctx.shadowColor = "#ffffff";
ctx.shadowBlur = 0;
ctx.fillText('$CITY$', 642, 2155, 1000);

//Greeting
ctx.font = 'bold 62px -apple-system';
ctx.textAlign = "center";
ctx.fillStyle = "#ffffff";
ctx.shadowOffsetY = 4;
ctx.shadowColor = "rgba(0,0,0,0.1)";
ctx.shadowBlur = 32;
ctx.fillText('$GREETING$', 642, 700, 1000);

//Line1
ctx.font = 'bold 42px -apple-system';
ctx.textAlign = "center";
ctx.fillStyle = "#ffffff";
ctx.shadowOffsetY = 4;
ctx.shadowColor = "rgba(0,0,0,0.1)";
ctx.shadowBlur = 32;
ctx.fillText('$STRING1$', 642, 880, 1000);