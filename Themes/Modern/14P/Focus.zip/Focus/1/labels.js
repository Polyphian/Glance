//LabelShadows
ctx.translate(0, 10);
ctx.shadowOffsetY = 4;
ctx.shadowColor = "rgba(0,0,0,0.9)";
ctx.shadowBlur = 28;